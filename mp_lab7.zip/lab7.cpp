#include <stdio.h>
#include <iostream>
#include <iomanip>

using namespace std;

/**

Menu
        1. Sześcian
        2. Ostrosłup o podstawie kwadratu
        3. Walec
        4. Kula
        5. Graniastosłup prawidłowy o podstawie trójkąta

W ramach realizacji zadania utwórz:
      * klasę abstrakcyjną "Bryła" zawierająca metody wirtualne "Objetosc" i "PCalkowite"
      * klasy specjalistyczne dziedziczące po klasie "Bryla" zawierające definicje odpowiednich pól jak i implementacje metod odziedziczonych, 
      a także ewentualne inne metody (metody dostępowe do pól, metody wyliczające pole powierzchni boku i podstawy jeżeli ich definicja jest uzasadniona)
*/

void menu();

int main(int argc, char const *argv[])
{
  menu();
  return 0;
}

void menu()
{
  int wybor;
  double s;

  do
  {
    cout << endl;
    cout << "MENU: " << endl;
    cout << "Program realizujący funkcje wyznaczania teoretycznego czasu przebycia wyznaczonej trasy okreslonym ponizej pojazdem:" << endl;
    cout << "(1) Szescian" << endl;
    cout << "(2) Ostroslup o podstawie kwadratu" << endl;
    cout << "(3) Walec" << endl;
    cout << "(4) Kula" << endl;
    cout << "(5) Graniastoslup prawidlowy o podstawie trojkata" << endl;
    cout << "(q) Wyjdz" << endl;
    cout << endl;
    cin >> wybor;

    switch (wybor)
    {
    case 1:
      /* code */
      break;
    case 2:
      /* code */
      break;
    case 3:
      /* code */
      break;
    case 4:
      /* code */
      break;
    case 5:
      /* code */
      break;
    }
  } while (wybor != 'q');
}