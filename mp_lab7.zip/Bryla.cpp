class Bryla {
    public: 
        virtual double Objetosc()=0;
        virtual double PCalkowite()=0;
};