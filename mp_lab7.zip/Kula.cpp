#include "Bryla.cpp"

class Kula : public Bryla
{
public:
    double Objetosc(){
        return 0;
    }

    double PCalkowite(){
        return 0;
    }

};