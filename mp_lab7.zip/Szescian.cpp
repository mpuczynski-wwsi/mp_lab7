#include "Bryla.cpp"

class Szescian : public Bryla
{
public:
    double Objetosc(){
        return 0;
    }

    double PCalkowite(){
        return 0;
    }

};