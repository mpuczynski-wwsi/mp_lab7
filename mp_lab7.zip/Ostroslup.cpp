#include "Bryla.cpp"

class Ostroslup : public Bryla
{
public:
    double Objetosc(){
        return 0;
    }

    double PCalkowite(){
        return 0;
    }

};