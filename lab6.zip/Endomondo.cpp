#include <stdio.h>
#include <iostream>

using namespace std;


class Endomondo {
    private:
        float *s;
        float *t;
        char *r;

    public:
        // konstruktor jednoargumentowy, którego argumentem jest długość pokonywanej trasy, zaś sposób jej pokonywania ustalony jest na c -chód
        Endomondo(float s){
            this->s = &s;
            this->r = new char('c');
        }

        Endomondo(float s, char r){
            this->s = &s;
            this->r = &r;
        }

        // metoda wyliczająca czas pokonania trasy
        float licz(){
            if (s <= 0) { cout << "s musi byc wieksze od 0" << endl;}
            if (r == 'c'){
                return 4. / s;
            } else if (r == 'r'){
                return 9. / s;

            } else if (r == 's'){
                return 65. / s;
            } else { 
                cout << "Bledny tryb" << endl;
                return 0.;
            }
        }
};